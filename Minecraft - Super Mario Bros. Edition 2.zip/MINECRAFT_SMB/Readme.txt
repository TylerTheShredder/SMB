Minecraft - SMB Edition by BWGLite
---------------------------------

Extra tips;
Use fast clouds! Clouds will look ugly with fancy mode enabled!

This pack will work with 20w14infinite and 23w13a_or_b!

For 20w14infinite, it is recommended to use the 'MC_SMB_20W14INF' pack located in the 'Compatibility Packs' folder.

For 23w13a_or_b and 1.19, use the MC_SMB_1_19_COMP pack;

It's not required, but it will fix a couple textures looking buggy, as their formatting has since changed.
Simply drag it out to your 'resourcepacks' folder, or copy and paste it in, and give it priority over the main SMB Edition pack.

Enjoy!! ^^